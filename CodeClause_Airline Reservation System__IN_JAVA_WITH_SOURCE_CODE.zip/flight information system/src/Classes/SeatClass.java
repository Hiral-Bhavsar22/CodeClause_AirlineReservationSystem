package Classes;

/**
 *
 * @author Madhushi
 */
public enum SeatClass {
    FIRST,
    BUSINESS,
    ECONOMY
}
